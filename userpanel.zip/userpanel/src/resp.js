{
    "user"
:
    {
        "id":
        1725, "firstName"
    :
        "Edyta", "lastName"
    :
        "Brudzisz", "email"
    :
        "e.brudzisz@gmail.com", "verified"
    :
        true
    }
,
    "refreshToken": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxNzI1IiwiYXV0aCI6InJlZnJlc2giLCJleHAiOjE1Nzg3NTg5MjV9.SFFeA43L1XXhree3KkvyyUJjv8JqC4qIoIOUIwgH5nvQ7EIBqUhd5VaGFXrZHxBKrXGIN576GSUQQU3GEgUHIg",
    "accessList":    [{
        "context": {"id": 1876, "name": "e.brudzisz@gmail.com", "generallyAvailable": false, "active": true},
        "tenantProperties": {
            "maxUsers": null,
            "maxDevices": 3,
            "maxReports": null,
            "maxDashboards": 2,
            "maxRules": 3,
            "assetCreationRules": {
                "publicDeviceCreation": true,
                "publicRuleCreation": true,
                "publicPointCreation": true,
                "publicCalculationCreation": true,
                "publicDashboardCreation": false,
                "publicReportCreation": false
            }
        },
        "accessToken": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxNzI1IiwiYXV0aCI6WyJVU0VSX0NSRUFURSIsIlVTRVJfUkVBRCIsIlVTRVJfVVBEQVRFIiwiVVNFUl9ERUxFVEUiLCJSVUxFX0NSRUFURSIsIlJVTEVfUkVBRCIsIlJVTEVfVVBEQVRFIiwiUlVMRV9ERUxFVEUiLCJERVZJQ0VfQ1JFQVRFIiwiREVWSUNFX1JFQUQiLCJERVZJQ0VfVVBEQVRFIiwiREVWSUNFX0RFTEVURSIsIkRFVklDRV9UWVBFX0NSRUFURSIsIkRFVklDRV9UWVBFX1JFQUQiLCJERVZJQ0VfVFlQRV9VUERBVEUiLCJERVZJQ0VfVFlQRV9ERUxFVEUiLCJQT0lOVF9DUkVBVEUiLCJQT0lOVF9SRUFEIiwiUE9JTlRfVVBEQVRFIiwiUE9JTlRfREVMRVRFIiwiUk9MRV9DUkVBVEUiLCJST0xFX1JFQUQiLCJST0xFX1VQREFURSIsIlJPTEVfREVMRVRFIiwiREFTSEJPQVJEX0NSRUFURSIsIkRBU0hCT0FSRF9SRUFEIiwiREFTSEJPQVJEX1VQREFURSIsIkRBU0hCT0FSRF9ERUxFVEUiLCJSRVBPUlRfQ1JFQVRFIiwiUkVQT1JUX1JFQUQiLCJSRVBPUlRfVVBEQVRFIiwiUkVQT1JUX0RFTEVURSIsIlRFTVBMQVRFX0NSRUFURSIsIlRFTVBMQVRFX1JFQUQiLCJURU1QTEFURV9VUERBVEUiLCJURU1QTEFURV9ERUxFVEUiLCJERVZJQ0VfR1JPVVBfTUFOQUdFTUVOVCIsIk5PVElGSUNBVElPTl9SRUFEIiwiTU9CSUxFX1JFQUQiLCJDT05URVhUX01BTkFHRU1FTlQiXSwiY29udGV4dCI6MTg3Niwicm9sZSI6MiwiZXhwIjoxNTc2MjUzMzI1fQ.66aoNJotK4z3b1cnL5cbqYmBKKMtyA8QIR8AM_3ZrGTGxrwzHsKFKC-Iq3vmP3f3SYS3zDFNHXa6pxIs1jdzeA",
        "role": {
            "id": 2,
            "name": "OWNER",
            "roleType": "SYSTEM",
            "description": "OWNER_ROLE_DESCRIPTION",
            "accessPermissions": ["USER_CREATE", "USER_READ", "USER_UPDATE", "USER_DELETE", "RULE_CREATE", "RULE_READ", "RULE_UPDATE", "RULE_DELETE", "DEVICE_CREATE", "DEVICE_READ", "DEVICE_UPDATE", "DEVICE_DELETE", "DEVICE_TYPE_CREATE", "DEVICE_TYPE_READ", "DEVICE_TYPE_UPDATE", "DEVICE_TYPE_DELETE", "POINT_CREATE", "POINT_READ", "POINT_UPDATE", "POINT_DELETE", "ROLE_CREATE", "ROLE_READ", "ROLE_UPDATE", "ROLE_DELETE", "DASHBOARD_CREATE", "DASHBOARD_READ", "DASHBOARD_UPDATE", "DASHBOARD_DELETE", "REPORT_CREATE", "REPORT_READ", "REPORT_UPDATE", "REPORT_DELETE", "TEMPLATE_CREATE", "TEMPLATE_READ", "TEMPLATE_UPDATE", "TEMPLATE_DELETE", "DEVICE_GROUP_MANAGEMENT", "NOTIFICATION_READ", "MOBILE_READ", "CONTEXT_MANAGEMENT"],
            "contextId": null
        }
    }]
}