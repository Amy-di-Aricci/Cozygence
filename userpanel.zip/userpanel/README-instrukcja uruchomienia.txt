1. Przed pierwszym uruchomieniem należy dokonać instalacji wszystkich potrzebnych paczek poleceniem
npm install
2. Uruchomienie projektu odbywa się poprzez użycie polecenia
npm run serve

Do poprawnego działania projektu wymagane jest środowisko uruchomieniowe Node.js oraz menedżer paczek npm. Można pobrać je ze strony: https://nodejs.org/en/